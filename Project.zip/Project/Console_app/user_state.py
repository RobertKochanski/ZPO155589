from typing import Optional

from Project.LogicLayer.Users.User import User


current_user: Optional[User] = None